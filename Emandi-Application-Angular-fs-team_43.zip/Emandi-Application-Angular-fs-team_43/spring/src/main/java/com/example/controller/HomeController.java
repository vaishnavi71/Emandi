package com.example.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

	@GetMapping("/")
	public String testApi(HttpServletResponse httpResponse) throws Exception {
		httpResponse.sendRedirect("/login");
		//just as it is
		return "/login";
	}
}
