package com.example.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.Models.ProductModel;
import com.example.Repositories.ProductRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {
    @Autowired
    ProductRepository productRepository;
    @GetMapping("/admin")
    public List<ProductModel> getHomeProduct()
    {
        List<ProductModel> listofObjects = new ArrayList<>();
        return productRepository.findAll();
    }
    @GetMapping("/admin/orders")
    public List<ProductModel> getProduct()
    {
        List<ProductModel> listofObjects = new ArrayList<>();
        return productRepository.findAll();
    }
   // @GetMapping("/admin/addProduct")
    @RequestMapping(method=RequestMethod.POST,value="/admin/addProduct")
    public boolean productSave(@RequestBody ProductModel data)
    {
        System.out.println(data.getProductName());
       // System.out.println(data.getDescription());
        productRepository.save(data);
        return true;
    }
    @GetMapping("/admin/productEdit/{id}")
    Optional<ProductModel> productEditData(@PathVariable String id)
    {
      return productRepository.findById(id);
      //return new ProductModel();
      
    }
    @RequestMapping(method=RequestMethod.POST,value="/admin/productEdit/{id}")
    public boolean productEditSave(@RequestBody ProductModel data,@PathVariable String id)
    {
        System.out.println(data.getProductName());
        productRepository.save(data);
        return true;
    }
    
    @GetMapping("/admin/delete/{id}")
    public boolean productDelete(@PathVariable String id)
    {
        System.out.println(id+" is id");
        if(!id.equals(null))
        productRepository.deleteById(id);
        else
        return false;
        return true;
    }

    
}
