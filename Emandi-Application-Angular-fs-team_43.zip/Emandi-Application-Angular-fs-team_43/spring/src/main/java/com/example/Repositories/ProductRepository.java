package com.example.Repositories;

import com.example.Models.ProductModel;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<ProductModel,String>{
    
}
